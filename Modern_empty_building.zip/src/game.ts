import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../7cd4d0bc-54d4-4f64-8ab2-6f18f41f03a3/src/item"
import Script2 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("models/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const wallPlainWhite3 = new Entity('wallPlainWhite3')
engine.addEntity(wallPlainWhite3)
wallPlainWhite3.setParent(_scene)
const gltfShape2 = new GLTFShape("models/PlainWhiteWall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
wallPlainWhite3.addComponentOrReplace(gltfShape2)
const transform3 = new Transform({
  position: new Vector3(16, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.085563659667969, 2.002985715866089, 1)
})
wallPlainWhite3.addComponentOrReplace(transform3)

const cyberpunkDoor = new Entity('cyberpunkDoor')
engine.addEntity(cyberpunkDoor)
cyberpunkDoor.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(10.775476455688477, 0, 3.776761531829834),
  rotation: new Quaternion(9.35170537064373e-15, -1, 1.1920928244535389e-7, -5.960464477539063e-8),
  scale: new Vector3(1, 1, 1)
})
cyberpunkDoor.addComponentOrReplace(transform4)

const wallPlainWhite = new Entity('wallPlainWhite')
engine.addEntity(wallPlainWhite)
wallPlainWhite.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(10.778055191040039, 0, 4.03056526184082),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8743575811386108, 1, 1)
})
wallPlainWhite.addComponentOrReplace(transform5)
wallPlainWhite.addComponentOrReplace(gltfShape2)

const floorDarkGrey2 = new Entity('floorDarkGrey2')
engine.addEntity(floorDarkGrey2)
floorDarkGrey2.setParent(_scene)
const gltfShape3 = new GLTFShape("models/DarkGreyFloor.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
floorDarkGrey2.addComponentOrReplace(gltfShape3)
const transform6 = new Transform({
  position: new Vector3(15.707210540771484, 0, 15.787334442138672),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.951627254486084, 1, 2.9776413440704346)
})
floorDarkGrey2.addComponentOrReplace(transform6)

const wallPlainWhite4 = new Entity('wallPlainWhite4')
engine.addEntity(wallPlainWhite4)
wallPlainWhite4.setParent(_scene)
wallPlainWhite4.addComponentOrReplace(gltfShape2)
const transform7 = new Transform({
  position: new Vector3(16, 0, 3.99005126953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6107231378555298, 1, 1)
})
wallPlainWhite4.addComponentOrReplace(transform7)

const wallPlainWhite2 = new Entity('wallPlainWhite2')
engine.addEntity(wallPlainWhite2)
wallPlainWhite2.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(15.704011917114258, 4, 16),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.752322673797607, 1, 1.0000053644180298)
})
wallPlainWhite2.addComponentOrReplace(transform8)
wallPlainWhite2.addComponentOrReplace(gltfShape2)

const wallPlainWhite5 = new Entity('wallPlainWhite5')
engine.addEntity(wallPlainWhite5)
wallPlainWhite5.setParent(_scene)
wallPlainWhite5.addComponentOrReplace(gltfShape2)
const transform9 = new Transform({
  position: new Vector3(7.333549499511719, 0, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.9668824672698975, 1, 1.0000042915344238)
})
wallPlainWhite5.addComponentOrReplace(transform9)

const windowFullWall = new Entity('windowFullWall')
engine.addEntity(windowFullWall)
windowFullWall.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(15.706747055053711, 0, 15.937174797058105),
  rotation: new Quaternion(1.539415254273621e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(6.100082874298096, 1, 0.009999881498515606)
})
windowFullWall.addComponentOrReplace(transform10)
const gltfShape4 = new GLTFShape("models/FullWallWindow.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
windowFullWall.addComponentOrReplace(gltfShape4)

const wallPlainWhite6 = new Entity('wallPlainWhite6')
engine.addEntity(wallPlainWhite6)
wallPlainWhite6.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(4, 0, 16),
  rotation: new Quaternion(1.5394153601527394e-15, -0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(8.00002670288086, 1, -1.0000033378601074)
})
wallPlainWhite6.addComponentOrReplace(transform11)
wallPlainWhite6.addComponentOrReplace(gltfShape2)

const wallPlainWhite7 = new Entity('wallPlainWhite7')
engine.addEntity(wallPlainWhite7)
wallPlainWhite7.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(7.1739091873168945, 0, 0.2989320755004883),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5986433029174805, 1, 1)
})
wallPlainWhite7.addComponentOrReplace(transform12)
wallPlainWhite7.addComponentOrReplace(gltfShape2)

const floorDarkGrey = new Entity('floorDarkGrey')
engine.addEntity(floorDarkGrey)
floorDarkGrey.setParent(_scene)
floorDarkGrey.addComponentOrReplace(gltfShape3)
const transform13 = new Transform({
  position: new Vector3(11.707210540771484, 4, 15.787334442138672),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.857825517654419, 1, 3.944653034210205)
})
floorDarkGrey.addComponentOrReplace(transform13)

const wallPlainWhite8 = new Entity('wallPlainWhite8')
engine.addEntity(wallPlainWhite8)
wallPlainWhite8.setParent(_scene)
wallPlainWhite8.addComponentOrReplace(gltfShape2)
const transform14 = new Transform({
  position: new Vector3(8.200112342834473, 4, 2.49005126953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5882434844970703, 1, 0.9999997019767761)
})
wallPlainWhite8.addComponentOrReplace(transform14)

const stairsGlassPanelCorner = new Entity('stairsGlassPanelCorner')
engine.addEntity(stairsGlassPanelCorner)
stairsGlassPanelCorner.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(13.5, 0, 11.5),
  rotation: new Quaternion(4.733207827279295e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
stairsGlassPanelCorner.addComponentOrReplace(transform15)
const gltfShape5 = new GLTFShape("models/glassPanelStairs_corner.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
stairsGlassPanelCorner.addComponentOrReplace(gltfShape5)

const floorDarkGrey3 = new Entity('floorDarkGrey3')
engine.addEntity(floorDarkGrey3)
floorDarkGrey3.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(16, 4, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2418582439422607, 1, 2.9966483116149902)
})
floorDarkGrey3.addComponentOrReplace(transform16)
floorDarkGrey3.addComponentOrReplace(gltfShape3)

const floorDarkGrey4 = new Entity('floorDarkGrey4')
engine.addEntity(floorDarkGrey4)
floorDarkGrey4.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(7.169376373291016, 0, 4),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.8439266681671143, 1, 1)
})
floorDarkGrey4.addComponentOrReplace(transform17)
floorDarkGrey4.addComponentOrReplace(gltfShape3)

const wallPlainWhite9 = new Entity('wallPlainWhite9')
engine.addEntity(wallPlainWhite9)
wallPlainWhite9.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(4.5, 4, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.2528908252716064, 1, 0.9999995827674866)
})
wallPlainWhite9.addComponentOrReplace(transform18)
wallPlainWhite9.addComponentOrReplace(gltfShape2)

const wallPlainWhite10 = new Entity('wallPlainWhite10')
engine.addEntity(wallPlainWhite10)
wallPlainWhite10.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(0, 4, 16),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.997224807739258, 1, 1.0000014305114746)
})
wallPlainWhite10.addComponentOrReplace(transform19)
wallPlainWhite10.addComponentOrReplace(gltfShape2)

const wallPlainWhite11 = new Entity('wallPlainWhite11')
engine.addEntity(wallPlainWhite11)
wallPlainWhite11.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(7.334467887878418, 4, 0.29990720748901367),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.636237621307373, 1, 1.000000238418579)
})
wallPlainWhite11.addComponentOrReplace(transform20)
wallPlainWhite11.addComponentOrReplace(gltfShape2)

const doorframeWhite = new Entity('doorframeWhite')
engine.addEntity(doorframeWhite)
doorframeWhite.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(7.0270161628723145, 4, 2.363438367843628),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000019073486328, 1, 1.0000019073486328)
})
doorframeWhite.addComponentOrReplace(transform21)
const gltfShape6 = new GLTFShape("models/WhiteDoorframe.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
doorframeWhite.addComponentOrReplace(gltfShape6)

const wallPlainWhite13 = new Entity('wallPlainWhite13')
engine.addEntity(wallPlainWhite13)
wallPlainWhite13.setParent(_scene)
wallPlainWhite13.addComponentOrReplace(gltfShape2)
const transform22 = new Transform({
  position: new Vector3(7.028451919555664, 4, 0.5280535221099854),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.2460917830467224, 1, 1.0000042915344238)
})
wallPlainWhite13.addComponentOrReplace(transform22)

const windowFullWall2 = new Entity('windowFullWall2')
engine.addEntity(windowFullWall2)
windowFullWall2.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(16, 4, 2.4871060848236084),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall2.addComponentOrReplace(transform23)
windowFullWall2.addComponentOrReplace(gltfShape4)

const floorDarkGrey5 = new Entity('floorDarkGrey5')
engine.addEntity(floorDarkGrey5)
floorDarkGrey5.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(7.039433479309082, 8, 15.796202659606934),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.7535911798477173, 1, 3.9459517002105713)
})
floorDarkGrey5.addComponentOrReplace(transform24)
floorDarkGrey5.addComponentOrReplace(gltfShape3)

const floorDarkGrey6 = new Entity('floorDarkGrey6')
engine.addEntity(floorDarkGrey6)
floorDarkGrey6.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(15.879993438720703, 8, 14.298940658569336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6187422871589661, 1, 2.9472599029541016)
})
floorDarkGrey6.addComponentOrReplace(transform25)
floorDarkGrey6.addComponentOrReplace(gltfShape3)

const stairsGlassPanelCorner2 = new Entity('stairsGlassPanelCorner2')
engine.addEntity(stairsGlassPanelCorner2)
stairsGlassPanelCorner2.setParent(_scene)
stairsGlassPanelCorner2.addComponentOrReplace(gltfShape5)
const transform26 = new Transform({
  position: new Vector3(11.39925765991211, 4, 13.5),
  rotation: new Quaternion(-6.498489287377722e-15, -7.450580596923828e-8, 1.0658141036401503e-14, -1),
  scale: new Vector3(0.9999998807907104, 1, 0.9999998807907104)
})
stairsGlassPanelCorner2.addComponentOrReplace(transform26)

const floorDarkGrey7 = new Entity('floorDarkGrey7')
engine.addEntity(floorDarkGrey7)
floorDarkGrey7.setParent(_scene)
floorDarkGrey7.addComponentOrReplace(gltfShape3)
const transform27 = new Transform({
  position: new Vector3(15.875335693359375, 8, 13.690607070922852),
  rotation: new Quaternion(-2.8013922782123843e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.5144561529159546, 1, 2.947258472442627)
})
floorDarkGrey7.addComponentOrReplace(transform27)

const floorDarkGrey8 = new Entity('floorDarkGrey8')
engine.addEntity(floorDarkGrey8)
floorDarkGrey8.setParent(_scene)
floorDarkGrey8.addComponentOrReplace(gltfShape3)
const transform28 = new Transform({
  position: new Vector3(15.8759765625, 8, 2.5),
  rotation: new Quaternion(-2.8013922782123843e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0289151668548584, 1, 2.9472599029541016)
})
floorDarkGrey8.addComponentOrReplace(transform28)

const floorDarkGrey9 = new Entity('floorDarkGrey9')
engine.addEntity(floorDarkGrey9)
floorDarkGrey9.setParent(_scene)
floorDarkGrey9.addComponentOrReplace(gltfShape3)
const transform29 = new Transform({
  position: new Vector3(15.5, 8, 5.361438751220703),
  rotation: new Quaternion(-2.8013922782123843e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.028916597366333, 1, 2.9472618103027344)
})
floorDarkGrey9.addComponentOrReplace(transform29)

const floorDarkGrey10 = new Entity('floorDarkGrey10')
engine.addEntity(floorDarkGrey10)
floorDarkGrey10.setParent(_scene)
floorDarkGrey10.addComponentOrReplace(gltfShape3)
const transform30 = new Transform({
  position: new Vector3(9.379993438720703, 8, 14.298940658569336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.9281134605407715, 1, 2.9472599029541016)
})
floorDarkGrey10.addComponentOrReplace(transform30)

const wallPlainWhite14 = new Entity('wallPlainWhite14')
engine.addEntity(wallPlainWhite14)
wallPlainWhite14.setParent(_scene)
wallPlainWhite14.addComponentOrReplace(gltfShape2)
const transform31 = new Transform({
  position: new Vector3(16, 4, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.085563659667969, 2.002985715866089, 1)
})
wallPlainWhite14.addComponentOrReplace(transform31)

const wallPlainWhite15 = new Entity('wallPlainWhite15')
engine.addEntity(wallPlainWhite15)
wallPlainWhite15.setParent(_scene)
wallPlainWhite15.addComponentOrReplace(gltfShape2)
const transform32 = new Transform({
  position: new Vector3(4.5, 8, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.2528908252716064, 1, 0.9999995827674866)
})
wallPlainWhite15.addComponentOrReplace(transform32)

const windowFullWall3 = new Entity('windowFullWall3')
engine.addEntity(windowFullWall3)
windowFullWall3.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(7.339634895324707, 4, 0.018875479698181152),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.5100036859512329, 2.163954496383667, 0.0010000019101426005)
})
windowFullWall3.addComponentOrReplace(transform33)
windowFullWall3.addComponentOrReplace(gltfShape4)

const windowFullWall4 = new Entity('windowFullWall4')
engine.addEntity(windowFullWall4)
windowFullWall4.setParent(_scene)
windowFullWall4.addComponentOrReplace(gltfShape4)
const transform34 = new Transform({
  position: new Vector3(15.998401641845703, 4, 2.5188751220703125),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.5100039839744568, 0.6266763806343079, 0.001000002259388566)
})
windowFullWall4.addComponentOrReplace(transform34)

const wallPlainWhite12 = new Entity('wallPlainWhite12')
engine.addEntity(wallPlainWhite12)
wallPlainWhite12.setParent(_scene)
wallPlainWhite12.addComponentOrReplace(gltfShape2)
const transform35 = new Transform({
  position: new Vector3(15.704011917114258, 8, 16),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.999207973480225, 1, 1.0000067949295044)
})
wallPlainWhite12.addComponentOrReplace(transform35)

const floorDarkGrey11 = new Entity('floorDarkGrey11')
engine.addEntity(floorDarkGrey11)
floorDarkGrey11.setParent(_scene)
floorDarkGrey11.addComponentOrReplace(gltfShape3)
const transform36 = new Transform({
  position: new Vector3(15.8759765625, 8, 0.3233470916748047),
  rotation: new Quaternion(-2.8013922782123843e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0289154052734375, 1, 2.9472603797912598)
})
floorDarkGrey11.addComponentOrReplace(transform36)

const wallPlainWhite16 = new Entity('wallPlainWhite16')
engine.addEntity(wallPlainWhite16)
wallPlainWhite16.setParent(_scene)
wallPlainWhite16.addComponentOrReplace(gltfShape2)
const transform37 = new Transform({
  position: new Vector3(16, 8, 0.2959709167480469),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, 1.088531040241566e-15, 1),
  scale: new Vector3(6.874661445617676, 1, 1.0000072717666626)
})
wallPlainWhite16.addComponentOrReplace(transform37)

const wallPlainWhite17 = new Entity('wallPlainWhite17')
engine.addEntity(wallPlainWhite17)
wallPlainWhite17.setParent(_scene)
wallPlainWhite17.addComponentOrReplace(gltfShape2)
const transform38 = new Transform({
  position: new Vector3(0, 8, 16),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.640631914138794, 1, 1.0000079870224)
})
wallPlainWhite17.addComponentOrReplace(transform38)

const windowFullWall5 = new Entity('windowFullWall5')
engine.addEntity(windowFullWall5)
windowFullWall5.setParent(_scene)
windowFullWall5.addComponentOrReplace(gltfShape4)
const transform39 = new Transform({
  position: new Vector3(0, 8, 0.01887635514140129),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.5100040435791016, 2.1639559268951416, 0.0010000019101426005)
})
windowFullWall5.addComponentOrReplace(transform39)

const windowFullWall6 = new Entity('windowFullWall6')
engine.addEntity(windowFullWall6)
windowFullWall6.setParent(_scene)
windowFullWall6.addComponentOrReplace(gltfShape4)
const transform40 = new Transform({
  position: new Vector3(0, 8, 8.72130012512207),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.5100043416023254, 2.176682233810425, 0.001000002259388566)
})
windowFullWall6.addComponentOrReplace(transform40)

const wallPlainWhite18 = new Entity('wallPlainWhite18')
engine.addEntity(wallPlainWhite18)
wallPlainWhite18.setParent(_scene)
wallPlainWhite18.addComponentOrReplace(gltfShape2)
const transform41 = new Transform({
  position: new Vector3(2.310993194580078, 8, 7.758881568908691),
  rotation: new Quaternion(4.740640117874978e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(0.553753137588501, 1, 1.000012993812561)
})
wallPlainWhite18.addComponentOrReplace(transform41)

const doorframeWhite2 = new Entity('doorframeWhite2')
engine.addEntity(doorframeWhite2)
doorframeWhite2.setParent(_scene)
doorframeWhite2.addComponentOrReplace(gltfShape6)
const transform42 = new Transform({
  position: new Vector3(2.0270161628723145, 8, 8.863438606262207),
  rotation: new Quaternion(3.0907076045336417e-15, 5.960464477539063e-8, -6.265249130351475e-16, 1),
  scale: new Vector3(1.0000029802322388, 1, 1.0000029802322388)
})
doorframeWhite2.addComponentOrReplace(transform42)

const windowFullWall7 = new Entity('windowFullWall7')
engine.addEntity(windowFullWall7)
windowFullWall7.setParent(_scene)
windowFullWall7.addComponentOrReplace(gltfShape4)
const transform43 = new Transform({
  position: new Vector3(2.2345666885375977, 8, 0.28785932064056396),
  rotation: new Quaternion(-1.5203487543891635e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall7.addComponentOrReplace(transform43)

const stairsGlassPanelCorner3 = new Entity('stairsGlassPanelCorner3')
engine.addEntity(stairsGlassPanelCorner3)
stairsGlassPanelCorner3.setParent(_scene)
stairsGlassPanelCorner3.addComponentOrReplace(gltfShape5)
const transform44 = new Transform({
  position: new Vector3(13.63245677947998, 8, 11.651127815246582),
  rotation: new Quaternion(7.484989597529232e-15, -1, 1.1920928955078125e-7, 8.940696716308594e-8),
  scale: new Vector3(0.9999998807907104, 1, 0.9999998807907104)
})
stairsGlassPanelCorner3.addComponentOrReplace(transform44)

const floorDarkGrey12 = new Entity('floorDarkGrey12')
engine.addEntity(floorDarkGrey12)
floorDarkGrey12.setParent(_scene)
floorDarkGrey12.addComponentOrReplace(gltfShape3)
const transform45 = new Transform({
  position: new Vector3(11.707210540771484, 12, 15.787334442138672),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.857825517654419, 1, 3.944653034210205)
})
floorDarkGrey12.addComponentOrReplace(transform45)

const floorDarkGrey13 = new Entity('floorDarkGrey13')
engine.addEntity(floorDarkGrey13)
floorDarkGrey13.setParent(_scene)
floorDarkGrey13.addComponentOrReplace(gltfShape3)
const transform46 = new Transform({
  position: new Vector3(16, 12, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2418582439422607, 1, 2.9966483116149902)
})
floorDarkGrey13.addComponentOrReplace(transform46)

const wallPlainWhite19 = new Entity('wallPlainWhite19')
engine.addEntity(wallPlainWhite19)
wallPlainWhite19.setParent(_scene)
wallPlainWhite19.addComponentOrReplace(gltfShape2)
const transform47 = new Transform({
  position: new Vector3(0, 12, 14),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.997581958770752, 1, 1.0000028610229492)
})
wallPlainWhite19.addComponentOrReplace(transform47)

const wallPlainWhite20 = new Entity('wallPlainWhite20')
engine.addEntity(wallPlainWhite20)
wallPlainWhite20.setParent(_scene)
wallPlainWhite20.addComponentOrReplace(gltfShape2)
const transform48 = new Transform({
  position: new Vector3(16, 8, 0.2959709167480469),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, 1.088531040241566e-15, 1),
  scale: new Vector3(6.874661445617676, 1, 1.0000072717666626)
})
wallPlainWhite20.addComponentOrReplace(transform48)

const wallPlainWhite21 = new Entity('wallPlainWhite21')
engine.addEntity(wallPlainWhite21)
wallPlainWhite21.setParent(_scene)
wallPlainWhite21.addComponentOrReplace(gltfShape2)
const transform49 = new Transform({
  position: new Vector3(10.5, 12, 0.2959715723991394),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, 1.088531040241566e-15, 1),
  scale: new Vector3(5.155994415283203, 1, 1.0000070333480835)
})
wallPlainWhite21.addComponentOrReplace(transform49)

const windowFullWall8 = new Entity('windowFullWall8')
engine.addEntity(windowFullWall8)
windowFullWall8.setParent(_scene)
windowFullWall8.addComponentOrReplace(gltfShape4)
const transform50 = new Transform({
  position: new Vector3(16, 12, 0.25177252292633057),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall8.addComponentOrReplace(transform50)

const wallPlainWhite22 = new Entity('wallPlainWhite22')
engine.addEntity(wallPlainWhite22)
wallPlainWhite22.setParent(_scene)
wallPlainWhite22.addComponentOrReplace(gltfShape2)
const transform51 = new Transform({
  position: new Vector3(15.704011917114258, 12, 16),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.999209880828857, 1, 1.0000070333480835)
})
wallPlainWhite22.addComponentOrReplace(transform51)

const wallPlainWhite23 = new Entity('wallPlainWhite23')
engine.addEntity(wallPlainWhite23)
wallPlainWhite23.setParent(_scene)
wallPlainWhite23.addComponentOrReplace(gltfShape2)
const transform52 = new Transform({
  position: new Vector3(16, 8, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.803475856781006, 2.002985715866089, 0.9999997615814209)
})
wallPlainWhite23.addComponentOrReplace(transform52)

const windowFullWall9 = new Entity('windowFullWall9')
engine.addEntity(windowFullWall9)
windowFullWall9.setParent(_scene)
windowFullWall9.addComponentOrReplace(gltfShape4)
const transform53 = new Transform({
  position: new Vector3(0.23456668853759766, 12, 13.787858963012695),
  rotation: new Quaternion(1.3891335041014605e-15, 1, -1.1920928244535389e-7, -5.960464477539063e-8),
  scale: new Vector3(4.156598091125488, 1, 0.0010000000474974513)
})
windowFullWall9.addComponentOrReplace(transform53)

const doorframeWhite3 = new Entity('doorframeWhite3')
engine.addEntity(doorframeWhite3)
doorframeWhite3.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(8.387836456298828, 12, 16),
  rotation: new Quaternion(-4.504429098665355e-16, 0.7071068286895752, -8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
doorframeWhite3.addComponentOrReplace(transform54)
doorframeWhite3.addComponentOrReplace(gltfShape6)

const wallPlainWhite24 = new Entity('wallPlainWhite24')
engine.addEntity(wallPlainWhite24)
wallPlainWhite24.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(8.386831283569336, 12, 14),
  rotation: new Quaternion(-6.692902301134779e-16, 0.7071068286895752, -8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(0.10740379244089127, 1, 1.0000042915344238)
})
wallPlainWhite24.addComponentOrReplace(transform55)
wallPlainWhite24.addComponentOrReplace(gltfShape2)

const windowFullWall10 = new Entity('windowFullWall10')
engine.addEntity(windowFullWall10)
windowFullWall10.setParent(_scene)
windowFullWall10.addComponentOrReplace(gltfShape4)
const transform56 = new Transform({
  position: new Vector3(0, 12, 15.97389030456543),
  rotation: new Quaternion(-3.8909345169742943e-16, 0, 0.7071067690849304, -0.7071068286895752),
  scale: new Vector3(0.5100043416023254, 2.176682472229004, 0.0010000023758038878)
})
windowFullWall10.addComponentOrReplace(transform56)

const windowFullWall11 = new Entity('windowFullWall11')
engine.addEntity(windowFullWall11)
windowFullWall11.setParent(_scene)
windowFullWall11.addComponentOrReplace(gltfShape4)
const transform57 = new Transform({
  position: new Vector3(0.020075082778930664, 12, 16),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.5100039839744568, 0.6266763806343079, 0.001000002259388566)
})
windowFullWall11.addComponentOrReplace(transform57)

const floorDarkGrey14 = new Entity('floorDarkGrey14')
engine.addEntity(floorDarkGrey14)
floorDarkGrey14.setParent(_scene)
floorDarkGrey14.addComponentOrReplace(gltfShape3)
const transform58 = new Transform({
  position: new Vector3(9.369720458984375, 16, 15.796202659606934),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.3356759548187256, 1, 3.945950746536255)
})
floorDarkGrey14.addComponentOrReplace(transform58)

const stairsGlassPanelCorner4 = new Entity('stairsGlassPanelCorner4')
engine.addEntity(stairsGlassPanelCorner4)
stairsGlassPanelCorner4.setParent(_scene)
stairsGlassPanelCorner4.addComponentOrReplace(gltfShape5)
const transform59 = new Transform({
  position: new Vector3(11.571651458740234, 12, 13.616415023803711),
  rotation: new Quaternion(-6.498489287377722e-15, -7.450580596923828e-8, 1.0658141036401503e-14, -1),
  scale: new Vector3(0.9999998807907104, 1, 0.9999998807907104)
})
stairsGlassPanelCorner4.addComponentOrReplace(transform59)

const floorDarkGrey15 = new Entity('floorDarkGrey15')
engine.addEntity(floorDarkGrey15)
floorDarkGrey15.setParent(_scene)
floorDarkGrey15.addComponentOrReplace(gltfShape3)
const transform60 = new Transform({
  position: new Vector3(15.916994094848633, 16, 0.016299843788146973),
  rotation: new Quaternion(-2.8013922782123843e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.3591983318328857, 1, 2.9472579956054688)
})
floorDarkGrey15.addComponentOrReplace(transform60)

const wallPlainWhite25 = new Entity('wallPlainWhite25')
engine.addEntity(wallPlainWhite25)
wallPlainWhite25.setParent(_scene)
wallPlainWhite25.addComponentOrReplace(gltfShape2)
const transform61 = new Transform({
  position: new Vector3(0, 16, 16),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(8.001896858215332, 1, 1.0000042915344238)
})
wallPlainWhite25.addComponentOrReplace(transform61)

const wallPlainWhite26 = new Entity('wallPlainWhite26')
engine.addEntity(wallPlainWhite26)
wallPlainWhite26.setParent(_scene)
wallPlainWhite26.addComponentOrReplace(gltfShape2)
const transform62 = new Transform({
  position: new Vector3(16, 16, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.972273349761963, 1, 0.9999995827674866)
})
wallPlainWhite26.addComponentOrReplace(transform62)

const wallPlainWhite27 = new Entity('wallPlainWhite27')
engine.addEntity(wallPlainWhite27)
wallPlainWhite27.setParent(_scene)
wallPlainWhite27.addComponentOrReplace(gltfShape2)
const transform63 = new Transform({
  position: new Vector3(15.704011917114258, 16, 16),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.376164197921753, 1, 1.000005841255188)
})
wallPlainWhite27.addComponentOrReplace(transform63)

const wallPlainWhite28 = new Entity('wallPlainWhite28')
engine.addEntity(wallPlainWhite28)
wallPlainWhite28.setParent(_scene)
wallPlainWhite28.addComponentOrReplace(gltfShape2)
const transform64 = new Transform({
  position: new Vector3(13.944134712219238, 16, 0.2959709167480469),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, 1.088531040241566e-15, 1),
  scale: new Vector3(6.874661445617676, 1, 1.0000072717666626)
})
wallPlainWhite28.addComponentOrReplace(transform64)

const doorframeWhite4 = new Entity('doorframeWhite4')
engine.addEntity(doorframeWhite4)
doorframeWhite4.setParent(_scene)
doorframeWhite4.addComponentOrReplace(gltfShape6)
const transform65 = new Transform({
  position: new Vector3(15.904905319213867, 16, 9.548710823059082),
  rotation: new Quaternion(8.490001812742985e-15, 0, 5.402340562204143e-15, -1),
  scale: new Vector3(1.000002145767212, 1, 1.000002145767212)
})
doorframeWhite4.addComponentOrReplace(transform65)

const floorDarkGrey16 = new Entity('floorDarkGrey16')
engine.addEntity(floorDarkGrey16)
floorDarkGrey16.setParent(_scene)
floorDarkGrey16.addComponentOrReplace(gltfShape3)
const transform66 = new Transform({
  position: new Vector3(15.992226600646973, 19.963134765625, 15.787334442138672),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.9825611114501953, 1, 3.944653034210205)
})
floorDarkGrey16.addComponentOrReplace(transform66)

const wallPlainWhite29 = new Entity('wallPlainWhite29')
engine.addEntity(wallPlainWhite29)
wallPlainWhite29.setParent(_scene)
wallPlainWhite29.addComponentOrReplace(gltfShape2)
const transform67 = new Transform({
  position: new Vector3(13.624449729919434, 16, 9.549724578857422),
  rotation: new Quaternion(-6.692902301134779e-16, 0.7071068286895752, -8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(0.14985132217407227, 1, 1.0000066757202148)
})
wallPlainWhite29.addComponentOrReplace(transform67)

const floorDarkGrey17 = new Entity('floorDarkGrey17')
engine.addEntity(floorDarkGrey17)
floorDarkGrey17.setParent(_scene)
floorDarkGrey17.addComponentOrReplace(gltfShape3)
const transform68 = new Transform({
  position: new Vector3(15.879993438720703, 16, 15.798940658569336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6187422871589661, 1, 1.738282322883606)
})
floorDarkGrey17.addComponentOrReplace(transform68)

const floorDarkGrey18 = new Entity('floorDarkGrey18')
engine.addEntity(floorDarkGrey18)
floorDarkGrey18.setParent(_scene)
floorDarkGrey18.addComponentOrReplace(gltfShape3)
const transform69 = new Transform({
  position: new Vector3(15.879993438720703, 16, 13.303013801574707),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.6187426447868347, 1, 1.7382837533950806)
})
floorDarkGrey18.addComponentOrReplace(transform69)

const windowFullWall12 = new Entity('windowFullWall12')
engine.addEntity(windowFullWall12)
windowFullWall12.setParent(_scene)
windowFullWall12.addComponentOrReplace(gltfShape4)
const transform70 = new Transform({
  position: new Vector3(7.338842868804932, 16, 0.018875474110245705),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.5100044012069702, 2.163957357406616, 0.0010000019101426005)
})
windowFullWall12.addComponentOrReplace(transform70)

const windowFullWall13 = new Entity('windowFullWall13')
engine.addEntity(windowFullWall13)
windowFullWall13.setParent(_scene)
windowFullWall13.addComponentOrReplace(gltfShape4)
const transform71 = new Transform({
  position: new Vector3(16, 16, 9.72130012512207),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.5100043416023254, 2.427304267883301, 0.001000002259388566)
})
windowFullWall13.addComponentOrReplace(transform71)

const windowFullWall14 = new Entity('windowFullWall14')
engine.addEntity(windowFullWall14)
windowFullWall14.setParent(_scene)
windowFullWall14.addComponentOrReplace(gltfShape4)
const transform72 = new Transform({
  position: new Vector3(13.706747055053711, 16, 9.437174797058105),
  rotation: new Quaternion(1.539415254273621e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(4.6941237449646, 1, 0.009999881498515606)
})
windowFullWall14.addComponentOrReplace(transform72)

const wallPlainWhite30 = new Entity('wallPlainWhite30')
engine.addEntity(wallPlainWhite30)
wallPlainWhite30.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(0.5000001788139343, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.12749995291233063, 1, 0.9999998211860657)
})
wallPlainWhite30.addComponentOrReplace(transform73)
wallPlainWhite30.addComponentOrReplace(gltfShape2)

const wallPlainWhite31 = new Entity('wallPlainWhite31')
engine.addEntity(wallPlainWhite31)
wallPlainWhite31.setParent(_scene)
wallPlainWhite31.addComponentOrReplace(gltfShape2)
const transform74 = new Transform({
  position: new Vector3(0.5000001788139343, 0, 8.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.12749995291233063, 1, 0.9999998211860657)
})
wallPlainWhite31.addComponentOrReplace(transform74)

const wallPlainWhite32 = new Entity('wallPlainWhite32')
engine.addEntity(wallPlainWhite32)
wallPlainWhite32.setParent(_scene)
wallPlainWhite32.addComponentOrReplace(gltfShape2)
const transform75 = new Transform({
  position: new Vector3(0.5000001788139343, 0, 1),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.12749995291233063, 1, 0.9999998211860657)
})
wallPlainWhite32.addComponentOrReplace(transform75)

const windowFullWall15 = new Entity('windowFullWall15')
engine.addEntity(windowFullWall15)
windowFullWall15.setParent(_scene)
windowFullWall15.addComponentOrReplace(gltfShape4)
const transform76 = new Transform({
  position: new Vector3(13.706747055053711, 16, 9.437174797058105),
  rotation: new Quaternion(1.539415254273621e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(4.6941237449646, 1, 0.009999881498515606)
})
windowFullWall15.addComponentOrReplace(transform76)

const windowFullWall16 = new Entity('windowFullWall16')
engine.addEntity(windowFullWall16)
windowFullWall16.setParent(_scene)
windowFullWall16.addComponentOrReplace(gltfShape4)
const transform77 = new Transform({
  position: new Vector3(13.706747055053711, 16, 9.437174797058105),
  rotation: new Quaternion(1.539415254273621e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(4.6941237449646, 1, 0.009999881498515606)
})
windowFullWall16.addComponentOrReplace(transform77)

const windowFullWall17 = new Entity('windowFullWall17')
engine.addEntity(windowFullWall17)
windowFullWall17.setParent(_scene)
windowFullWall17.addComponentOrReplace(gltfShape4)
const transform78 = new Transform({
  position: new Vector3(16, 12, 0.25177252292633057),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall17.addComponentOrReplace(transform78)

const windowFullWall18 = new Entity('windowFullWall18')
engine.addEntity(windowFullWall18)
windowFullWall18.setParent(_scene)
windowFullWall18.addComponentOrReplace(gltfShape4)
const transform79 = new Transform({
  position: new Vector3(16, 12, 0.25177252292633057),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall18.addComponentOrReplace(transform79)

const windowFullWall19 = new Entity('windowFullWall19')
engine.addEntity(windowFullWall19)
windowFullWall19.setParent(_scene)
windowFullWall19.addComponentOrReplace(gltfShape4)
const transform80 = new Transform({
  position: new Vector3(16, 4, 2.4871060848236084),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall19.addComponentOrReplace(transform80)

const windowFullWall20 = new Entity('windowFullWall20')
engine.addEntity(windowFullWall20)
windowFullWall20.setParent(_scene)
windowFullWall20.addComponentOrReplace(gltfShape4)
const transform81 = new Transform({
  position: new Vector3(16, 4, 2.4871060848236084),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall20.addComponentOrReplace(transform81)

const windowFullWall21 = new Entity('windowFullWall21')
engine.addEntity(windowFullWall21)
windowFullWall21.setParent(_scene)
windowFullWall21.addComponentOrReplace(gltfShape4)
const transform82 = new Transform({
  position: new Vector3(15.706747055053711, 0, 15.937174797058105),
  rotation: new Quaternion(1.539415254273621e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(6.100082874298096, 1, 0.009999881498515606)
})
windowFullWall21.addComponentOrReplace(transform82)

const windowFullWall22 = new Entity('windowFullWall22')
engine.addEntity(windowFullWall22)
windowFullWall22.setParent(_scene)
windowFullWall22.addComponentOrReplace(gltfShape4)
const transform83 = new Transform({
  position: new Vector3(15.706747055053711, 0, 15.937174797058105),
  rotation: new Quaternion(1.539415254273621e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(6.100082874298096, 1, 0.009999881498515606)
})
windowFullWall22.addComponentOrReplace(transform83)

const windowFullWall23 = new Entity('windowFullWall23')
engine.addEntity(windowFullWall23)
windowFullWall23.setParent(_scene)
windowFullWall23.addComponentOrReplace(gltfShape4)
const transform84 = new Transform({
  position: new Vector3(2.2345666885375977, 8, 0.28785932064056396),
  rotation: new Quaternion(-1.5203487543891635e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall23.addComponentOrReplace(transform84)

const windowFullWall24 = new Entity('windowFullWall24')
engine.addEntity(windowFullWall24)
windowFullWall24.setParent(_scene)
windowFullWall24.addComponentOrReplace(gltfShape4)
const transform85 = new Transform({
  position: new Vector3(2.2345666885375977, 8, 0.28785932064056396),
  rotation: new Quaternion(-1.5203487543891635e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(4, 1, 0.0009999999310821295)
})
windowFullWall24.addComponentOrReplace(transform85)

const windowFullWall25 = new Entity('windowFullWall25')
engine.addEntity(windowFullWall25)
windowFullWall25.setParent(_scene)
windowFullWall25.addComponentOrReplace(gltfShape4)
const transform86 = new Transform({
  position: new Vector3(0.23456668853759766, 12, 13.787858963012695),
  rotation: new Quaternion(1.3891335041014605e-15, 1, -1.1920928244535389e-7, -5.960464477539063e-8),
  scale: new Vector3(4.156598091125488, 1, 0.0010000000474974513)
})
windowFullWall25.addComponentOrReplace(transform86)

const windowFullWall26 = new Entity('windowFullWall26')
engine.addEntity(windowFullWall26)
windowFullWall26.setParent(_scene)
windowFullWall26.addComponentOrReplace(gltfShape4)
const transform87 = new Transform({
  position: new Vector3(0.23456668853759766, 12, 13.787858963012695),
  rotation: new Quaternion(1.3891335041014605e-15, 1, -1.1920928244535389e-7, -5.960464477539063e-8),
  scale: new Vector3(4.156598091125488, 1, 0.0010000000474974513)
})
windowFullWall26.addComponentOrReplace(transform87)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(11.627961158752441, 4, 0.01829417049884796),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7533990144729614, 1, 0.9999999403953552)
})
ropeLight.addComponentOrReplace(transform88)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(15.98935604095459, 4, 1.2592488527297974),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.213181734085083, 1, 1.0000020265579224)
})
ropeLight2.addComponentOrReplace(transform89)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(0.010132073424756527, 9, 4.375988006591797),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.7534006237983704, 1, 1.000001311302185)
})
ropeLight3.addComponentOrReplace(transform90)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(1.234755516052246, 9, 0.015003681182861328),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(0.21318213641643524, 1, 1.000003695487976)
})
ropeLight4.addComponentOrReplace(transform91)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(11.627961158752441, 5, 0.01829417049884796),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7533990144729614, 1, 0.9999999403953552)
})
ropeLight5.addComponentOrReplace(transform92)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(15.98935604095459, 5, 1.2592488527297974),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.21318179368972778, 1, 1.0000022649765015)
})
ropeLight6.addComponentOrReplace(transform93)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(15.975753784179688, 17, 4.655081748962402),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.8009400367736816, 1, 1.0000029802322388)
})
ropeLight7.addComponentOrReplace(transform94)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(14.756916046142578, 17, 0.015002073720097542),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(0.21318213641643524, 1, 1.000003695487976)
})
ropeLight8.addComponentOrReplace(transform95)

const ropeLight9 = new Entity('ropeLight9')
engine.addEntity(ropeLight9)
ropeLight9.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(4.216158866882324, 13, 15.988531112670898),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7258778810501099, 1, 0.9999999403953552)
})
ropeLight9.addComponentOrReplace(transform96)

const ropeLight10 = new Entity('ropeLight10')
engine.addEntity(ropeLight10)
ropeLight10.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(0.019281502813100815, 13, 14.759248733520508),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.21318233013153076, 1, 1.0000041723251343)
})
ropeLight10.addComponentOrReplace(transform97)

const ringWhiteLight = new Entity('ringWhiteLight')
engine.addEntity(ringWhiteLight)
ringWhiteLight.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(13, 14, 0.11040687561035156),
  rotation: new Quaternion(-0.5, -0.5, 0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(1.0000005960464478, 1.0000007152557373, 1.0000003576278687)
})
ringWhiteLight.addComponentOrReplace(transform98)
const gltfShape7 = new GLTFShape("models/Ring_White_Light.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
ringWhiteLight.addComponentOrReplace(gltfShape7)

const ropeLight11 = new Entity('ropeLight11')
engine.addEntity(ropeLight11)
ropeLight11.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(14.756916046142578, 19.929414749145508, 0.015002073720097542),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(0.21318213641643524, 1, 1.000003695487976)
})
ropeLight11.addComponentOrReplace(transform99)

const ropeLight12 = new Entity('ropeLight12')
engine.addEntity(ropeLight12)
ropeLight12.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(15.975753784179688, 19.927005767822266, 4.655081748962402),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.8009404540061951, 1, 1.0000032186508179)
})
ropeLight12.addComponentOrReplace(transform100)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
script1.init(options)
script2.init(options)
script1.spawn(cyberpunkDoor, {"onClickText":"Open/Close","onClick":[{"entityName":"cyberpunkDoor","actionId":"toggle","values":{}}],"onOpen":[]}, createChannel(channelId, cyberpunkDoor, channelBus))
script2.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script2.spawn(ropeLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight2, channelBus))
script2.spawn(ropeLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight3, channelBus))
script2.spawn(ropeLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight4, channelBus))
script2.spawn(ropeLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight5, channelBus))
script2.spawn(ropeLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight6, channelBus))
script2.spawn(ropeLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight7, channelBus))
script2.spawn(ropeLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight8, channelBus))
script2.spawn(ropeLight9, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight9, channelBus))
script2.spawn(ropeLight10, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight10, channelBus))
script2.spawn(ropeLight11, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight11, channelBus))
script2.spawn(ropeLight12, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight12, channelBus))